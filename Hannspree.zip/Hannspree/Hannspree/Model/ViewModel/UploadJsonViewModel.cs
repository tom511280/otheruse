﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hannspree.Model.ViewModel
{
    public class UploadJsonViewModel
    {
        /// <summary>
        /// S3路徑
        /// </summary>
        public string Path { get; set; }
        /// <summary>
        /// Json String
        /// </summary>
        public string JsonData { get; set; }
    }
}
