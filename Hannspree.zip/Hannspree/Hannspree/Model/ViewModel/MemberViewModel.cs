﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hannspree.Model
{
    public class MemberViewModel
    {

    }

    public class MemberInfoOnForeign : MemberInfo
    {
        /// <summary>
        /// 外部登入編號
        /// </summary>
        public string ForeignKey { get; set; }
        /// <summary>
        /// 電子郵件
        /// </summary>
        public string Email { get; set; }
        /// <summary>
        /// 外部登入編碼來源
        /// </summary>
        public bool Google { get; set; }
        /// <summary>
        /// 外部登入編碼來源
        /// </summary>
        public bool Apple { get; set; }
        /// <summary>
        /// 外部登入編碼來源
        /// </summary>
        //public bool Facebook { get; set; }
    }

    public class MemberInfoOnInner : MemberInfo
    {
        /// <summary>
        /// 帳號(Email)
        /// </summary>
        public string Account { get; set; }
        /// <summary>
        /// 密碼
        /// </summary>
        public string Password { get; set; }
    }
    public class MemberInfo
    {
        /// <summary>
        /// 使用者名稱
        /// </summary>
        public string UserName { get; set; }               
        /// <summary>
        /// 裝置Id
        /// </summary>
        public string DeviceId { get; set; }
        /// <summary>
        /// 使用者圖片Url
        /// </summary>
        public string ImgUrl { get; set; }
        /// <summary>
        /// 生日yyyy-MM-dd
        /// </summary>
        public DateTime? BirthDay { get; set; }
        /// <summary>
        /// 性別(男：1 女：0)
        /// </summary>
        public int? Gender { get; set; }
        /// <summary>
        /// 國家(英文縮寫 Ex：TW、CN)
        /// </summary>
        public string Country { get; set; }

    }


    [Serializable]
    public class MemberInfoUpdate
    {
        /// <summary>
        /// 流水號
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 密碼
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// 使用者名稱
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 電子郵件
        /// </summary>
        public string Email { get; set; }
        /// <summary>
        /// 裝置Id
        /// </summary>
        public string DeviceId { get; set; }
        /// <summary>
        /// 使用者圖片Url
        /// </summary>
        public string ImgUrl { get; set; }
        /// <summary>
        /// 生日
        /// </summary>
        public DateTime? BirthDay { get; set; }

    }

    public class MemberLogin
    {
        /// <summary>
        /// 外部登入編號
        /// </summary>
        public string ForeignKey { get; set; }
        /// <summary>
        /// 帳號
        /// </summary>
        public string Account { get; set; }
        /// <summary>
        /// 密碼
        /// </summary>
        public string Password { get; set; }
    }

    public class MemberLoginRsp
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        /// <summary>
        /// 不為外部登入則為null
        /// </summary>
        public string ForeignKey { get; set; }
        /// <summary>
        /// 為外部登入則為null
        /// </summary>
        public string Account { get; set; }
        public string Email { get; set; }
        public string DeviceId { get; set; }
        /// <summary>
        /// 相對路徑
        /// </summary>
        public string Path { get; set; }
        /// <summary>
        /// 實體路徑網域
        /// </summary>
        public string PhysicalPath { get; set; }
        public string ImgUrl { get; set; }
        public string Birthday { get; set; }
    }

    public class ForgotPasswordReq
    {
        public string UserName { get; set; }
        public string Account { get; set; }
        /// <summary>
        /// yyyy-MM-dd
        /// </summary>
        public DateTime BirthDay { get; set; }
    }

    public class ForgotPasswordRsp
    {
        public string UserName { get; set; }
        public string Account { get; set; }
        public string Password { get; set; }
    }

    public class PublicMemberLogin
    {
        /// <summary>
        /// 帳號
        /// </summary>
        public string Account { get; set; }
        /// <summary>
        /// 密碼
        /// </summary>
        public string Password { get; set; }
    }

    public class PublicMemberLoginRsp
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string Account { get; set; }
        public string Email { get; set; }
        public string DeviceId { get; set; }
        public string ImgUrl { get; set; }
        public string Birthday { get; set; }
    }
}
