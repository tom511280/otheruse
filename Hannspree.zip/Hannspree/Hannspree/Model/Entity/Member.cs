﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Hannspree.Model.Entity
{
    public class Member
    {
        [Key]
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string ForeignKey { get; set; }
        public string Account { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string BirthDay { get; set; }
        public int? Gender { get; set; }
        public string Country { get; set; }
        public string DeviceId { get; set; }
        public string ImgUrl { get; set; }
        public string Path { get; set; }
        public bool Google { get; set; }
        public bool Apple { get; set; }
        //public bool Facebook { get; set; }

    }
}
