﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Hannspree.Model.Entity
{
    public class UrlMapping
    {
        [Key]
        public int Id { get; set; }
        public string Origin { get; set; }
        public string Dest { get; set; }
    }
}
