﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Hannspree.Common
{
    public class RspMsg<T>
    {
        public HttpStatusCode? statusCode { get; set; }
        public bool Success { get; set; }
        public T obj { get; set; }
        public string Msg { get; set; }
    }
}
