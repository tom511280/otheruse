﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Hannspree.Model;
using Hannspree.Model.Entity;
using Hannspree.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace Hannspree.Controllers
{
    public class MemberController : Controller
    {
        private readonly JwtHelpers jwt;
        private DBHelper _dBHelper;

        public MemberController(DBHelper dBHelper, JwtHelpers jwt)
        {
            this.jwt = jwt;
            _dBHelper = dBHelper;
        }

        /// <summary>
        /// 建立或會員(使用外部登入)
        /// </summary>
        /// <response code="200">帳號登入成功</response>
        /// <response code="201">帳號建立成功</response>
        /// <response code="400">資料有誤</response>
        [Route("api/Member/CreateOrLoginMemberOnForeign")]
        [HttpPost]
        [ProducesResponseType(typeof(MemberLoginRsp), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(MemberLoginRsp), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateOrLoginMemberOnForeign([FromBody] MemberInfoOnForeign info)
        {
            var result = await _dBHelper.CreateOrLoginMemberOnForeign(info);
            if (result.Success)
            {
                return StatusCode((int)result.statusCode, result.obj);
            }
            return BadRequest(result.Msg);
        }

        /// <summary>
        /// 建立會員(使用email建立)
        /// </summary>
        /// <response code="201">帳號建立成功</response>
        /// <response code="400">資料有誤</response>
        /// <response code="403">帳號已存在</response>
        [Route("api/Member/CreateOnInner")]
        [HttpPost]
        [ProducesResponseType(typeof(MemberLoginRsp), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> CreateOnInner([FromBody] MemberInfoOnInner info)
        {
            var result = await _dBHelper.CreateMemberOnInner(info);
            if (result.Success)
            {
                return Created("", result.obj);
            }
            else
            {
                return StatusCode((int)result.statusCode, result.Msg);
            }
            
        }

        /// <summary>
        /// 會員資料更新
        /// </summary>
        /// <response code="200">修改成功</response>
        /// <response code="204">帳號不存在</response>
        [Route("api/Member/Update")]
        [HttpPatch]
        [ProducesResponseType(typeof(Member), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public async Task<IActionResult> Update([FromBody] MemberInfoUpdate info)
        {
            var result = await _dBHelper.UpdateMemberInfo(info);
            if (result != null)
            {
                return Ok(result);
            }
            return NoContent();
        }

        /// <summary>
        /// 會員登入
        /// </summary>
        /// <response code="200">登入成功</response>
        /// <response code="400">帳號或密碼錯誤</response>
        /// <response code="404">帳號不存在</response>
        [Route("api/Member/Login")]
        [HttpPost]
        [ProducesResponseType(typeof(MemberLoginRsp), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Login([FromBody] MemberLogin login)
        {
            var user = await _dBHelper.QueryUser(login);
            if (user != null)
            {
                var result = new MemberLoginRsp
                {
                    UserId = user.UserId,
                    UserName = user.UserName,
                    Email = user.Email,
                    DeviceId = user.DeviceId,
                    Path = user.Path,
                    PhysicalPath = "https://hannswear.s3-ap-northeast-1.amazonaws.com/" + user.Path,
                    ImgUrl = user.ImgUrl,
                    Birthday = user.BirthDay
                };
                if (!string.IsNullOrWhiteSpace(user.ForeignKey))
                {
                    result.ForeignKey = user.ForeignKey;
                }
                else
                {
                    result.Account = user.Account;
                    if(user.Password != login.Password)
                    {
                        return BadRequest("帳號或密碼錯誤！");
                    }
                }
                return Ok(result);
            }
            
            return NotFound("帳號不存在！");
        }

        /// <summary>
        /// 忘記密碼
        /// </summary>
        [Route("api/Member/ForgotPwd")]
        [HttpPost]
        public async Task<string> ForgotPwd([FromBody] ForgotPasswordReq req)
        {
            var result = await _dBHelper.ForgotPassword(req);
            if (result.Success)
            {
                return "密碼已寄到電子信箱！";
            }
            else
            {
                return result.Msg;
            }
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}