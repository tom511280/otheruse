﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hannspree.Model;
using Hannspree.Model.Entity;
using Hannspree.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Hannspree.Controllers
{
    [Route("[controller]")]
    public class PublicController : Controller
    {
        private readonly DBHelper dBHelper;

        public PublicController(DBHelper dBHelper)
        {
            this.dBHelper = dBHelper;
        }

        /// <summary>
        /// 註冊會員
        /// </summary>
        /// <response code="201">帳號建立成功</response>
        /// <response code="400">資料有誤</response>
        /// <response code="403">帳號已存在</response>
        [Route("Member/Register")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> CreateOnInner([FromBody] MemberInfoOnInner info)
        {
            var result = await dBHelper.CreateMemberOnInner(info);
            if (result.Success)
            {
                return Created("", "會員註冊成功！");
            }
            else
            {
                return StatusCode((int)result.statusCode, result.Msg);
            }

        }

        /// <summary>
        /// 會員資料更新
        /// </summary>
        /// <response code="200">修改成功</response>
        /// <response code="204">帳號不存在</response>
        [Route("Member/Update")]
        [HttpPatch]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public async Task<IActionResult> Update([FromBody] MemberInfoUpdate info)
        {
            var result = await dBHelper.UpdateMemberInfo(info);
            if (result != null)
            {
                return Ok("更新成功！");
            }
            return NoContent();
        }

        /// <summary>
        /// 會員登入
        /// </summary>
        /// <response code="200">登入成功</response>
        /// <response code="400">帳號或密碼錯誤</response>
        /// <response code="404">帳號不存在</response>
        [Route("Member/Signin")]
        [HttpPost]
        [ProducesResponseType(typeof(PublicMemberLoginRsp), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Login([FromBody] PublicMemberLogin req)
        {
            var login = new MemberLogin { Account = req.Account, Password = req.Password };
            var user = await dBHelper.QueryUser(login);
            if (user != null)
            {
                if (user.Password != login.Password)
                {
                    return BadRequest("帳號或密碼錯誤！");
                }
                var result = new PublicMemberLoginRsp
                {
                    UserId = user.UserId,
                    Account = user.Account,
                    UserName = user.UserName,
                    Email = user.Email,
                    DeviceId = user.DeviceId,
                    ImgUrl = user.ImgUrl,
                    Birthday = user.BirthDay
                };
                 
                return Ok(result);
            }

            return NotFound("帳號不存在！");
        }

        /// <summary>
        /// 忘記密碼
        /// </summary>
        [Route("Member/ForgotPwd")]
        [HttpPost]
        public async Task<string> ForgotPwd([FromBody] ForgotPasswordReq req)
        {
            var result = await dBHelper.ForgotPassword(req);
            if (result.Success)
            {
                return "密碼已寄到電子信箱！";
            }
            else
            {
                return result.Msg;
            }
        }
    }
}