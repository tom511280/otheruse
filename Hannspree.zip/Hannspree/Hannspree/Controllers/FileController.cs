﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mime;
using System.Threading.Tasks;
using Hannspree.Model.ViewModel;
using Hannspree.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Hannspree.Controllers
{
    //[Route("api/[controller]")]
    public class FileController : Controller
    {
        private DBHelper _dBHelper;
        public readonly AWSService _service;
        public FileController(AWSService service, DBHelper dBHelper)
        {
            _service = service;
            _dBHelper = dBHelper;
        }
        /// <summary>
        /// 檔案上傳到S3
        /// </summary>
        /// <param name="file">檔案</param>
        /// <param name="location">S3路徑</param>
        /// <returns></returns>
        [Route("api/File/UploadFile")]
        [HttpPost]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UploadFile(IFormFile file, [FromForm]string location)
        {
            var ms = new MemoryStream();
            await file.CopyToAsync(ms);

            if (string.IsNullOrWhiteSpace(location))
            {
                location = file.FileName;
            }

            var result = await _service.UploadFileToS3(ms, location);
            if (!string.IsNullOrWhiteSpace(result))
            {
                return Ok(result);
            }

            return BadRequest("上傳失敗！");
        }

        /// <summary>
        /// Json上傳到S3
        /// </summary>
        /// <returns></returns>
        [Route("api/File/UploadJson")]
        [HttpPost]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UploadJson([FromBody] UploadJsonViewModel data)
        {
            if (!string.IsNullOrEmpty(data.Path) && !string.IsNullOrEmpty(data.JsonData))
            {
                var ms = new MemoryStream();
                var writer = new StreamWriter(ms);
                writer.Write(data.JsonData);
                writer.Flush();

                var result = await _service.UploadFileToS3(ms, data.Path); 
                if (!string.IsNullOrWhiteSpace(result))
                {
                    return Ok(result);
                }
                
            }
            return BadRequest("上傳失敗！");
        }

        /// <summary>
        /// 刪除S3檔案
        /// </summary>
        [Route("api/File/DeleteS3File")]
        [HttpDelete]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> DeleteS3File(string key)
        {
            if(!string.IsNullOrWhiteSpace(key))
            {
                var result = await _service.DeleteFileOnS3(key);
                return Ok();
            }
            return BadRequest();
        }

        /// <summary>
        /// 計算資料夾大小
        /// </summary>
        [Route("api/File/CalculateFolderSize")]
        [HttpPost]
        [ProducesResponseType(typeof(long), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> CalculateFolderSize(string folderName)
        {
            if(!string.IsNullOrWhiteSpace(folderName))
            {
                var result = await _service.CalculateFolderSize(folderName);
                return Ok(result);
            }
            return NotFound();
        }

        [HttpGet]
        [Route("doc/{product}")]
        public ActionResult DownloadDoc(string product)
        {
            var origin = $"doc/{product}";
            var result = _dBHelper.UrlMapping(origin).Result;
            if (!string.IsNullOrWhiteSpace(result))
            {
                return Redirect(result);
            }
            return Redirect("https://www.hannswear.com/hannswapp");
        }

        [HttpGet]
        [Route("app/{product}")]
        public ActionResult DownloadApp(string product)
        {
            var req = Request.Headers["User-Agent"].ToString().ToLower();
            var os = "";
            if(req.Contains("mac"))
            {
                os = "ios";
            }
            else if(req.Contains("android"))
            {
                os = "android";
            }
            var origin = $"app/{product}/{os}";
            var result = _dBHelper.UrlMapping(origin).Result;
            if(!string.IsNullOrWhiteSpace(result))
            {
                return Redirect(result);
            }
            return Redirect("https://www.hannswear.com/hannswapp");
        }

        [HttpGet]
        [Route("app/test")]
        public ActionResult GetHeader()
        {
            var req = Request.Headers["User-Agent"].ToString();
            return Content(req);
        }

        [HttpPost]
        [Route("app/test2")]
        public async Task<bool> Test(string o, string d)
        {
            return await _dBHelper.UpdateUrlMapping(o, d);
        }
    }
}