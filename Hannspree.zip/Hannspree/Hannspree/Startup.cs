using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hannspree.Model.Entity;
using Hannspree.Service;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;

namespace Hannspree
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddOpenApiDocument();
            services.AddDbContext<DBContext>(options =>
            {
                //options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"));
                options.UseMySQL(Configuration.GetConnectionString("DefaultConnection"));
            });
            //services.AddControllersWithViews();
            services.AddMvc();
            services.AddSingleton<JwtHelpers>();
            services.AddScoped<DBHelper>();
            services.AddSingleton<AWSService>();
            //services.AddIdentityServer()
            //    .AddInMemoryApiResources(IdentityConfig.GetResources())
            //    .AddInMemoryApiScopes(IdentityConfig.GetScopes())
            //    .AddInMemoryClients(IdentityConfig.GetClients())
            //    // �۰ʫإ߶}�o�H���Ϊ��K�_(tempkey.jwk)�A���s�b�ɷ|�۰ʫإ�
            //    .AddDeveloperSigningCredential();

            //services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            //.AddJwtBearer(options =>
            //{
            //    // �����ҥ��ѮɡA�^�����Y�|�]�t WWW-Authenticate ���Y�A�o�̷|��ܥ��Ѫ��Բӿ��~��]
            //    options.IncludeErrorDetails = true; // �w�]�Ȭ� true�A���ɷ|�S�O����

            //    options.TokenValidationParameters = new TokenValidationParameters
            //    {
            //        // �z�L�o���ŧi�A�N�i�H�q "sub" ���Ȩó]�w�� User.Identity.Name
            //        NameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier",
            //        // �z�L�o���ŧi�A�N�i�H�q "roles" ���ȡA�åi�� [Authorize] �P�_����
            //        RoleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role",

            //        // �@��ڭ̳��|���� Issuer
            //        ValidateIssuer = true,
            //        ValidIssuer = Configuration.GetValue<string>("JwtSettings:Issuer"),

            //        // �q�`���ӻݭn���� Audience
            //        ValidateAudience = false,
            //        //ValidAudience = "JwtAuthDemo", // �����ҴN���ݭn��g

            //        // �@��ڭ̳��|���� Token �����Ĵ���
            //        ValidateLifetime = true,

            //        // �p�G Token ���]�t key �~�ݭn���ҡA�@�볣�u��ñ���Ӥw
            //        ValidateIssuerSigningKey = false,

            //        // "1234567890123456" ���ӱq IConfiguration ���o
            //        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration.GetValue<string>("JwtSettings:SignKey")))
            //    };
            //});
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseAuthentication();

            app.UseAuthorization();

            //app.UseIdentityServer();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapGet("/", async context =>
                {
                    await context.Response.WriteAsync("Welcome Hannspree!");
                });
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=[Controller]}/{action=[Action]}");
            });

            app.UseOpenApi();
            app.UseSwaggerUi3();
            app.UseReDoc(config =>  // serve ReDoc UI
            {
                // �o�̪� Path �Ψӳ]�w ReDoc UI ������ (���}���|) (�@�w�n�H / �׽u�}�Y)
                config.Path = "/redoc";
            });
        }
    }
}
