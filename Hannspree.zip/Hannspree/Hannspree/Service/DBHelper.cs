﻿using Hannspree.Common;
using Hannspree.Model;
using Hannspree.Model.Entity;
using K4os.Compression.LZ4.Internal;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Hannspree.Service
{
    public class DBHelper
    {
        private readonly DBContext _dBContext;
        private readonly ILogger<DBHelper> _logger;
        private readonly AWSService _service;

        public DBHelper(ILogger<DBHelper> logger, DBContext dBContext, AWSService service)
        {
            _logger = logger;
            _dBContext = dBContext;
            _service = service;
        }

        /// <summary>
        /// 建立會員
        /// </summary>
        public async Task<RspMsg<MemberLoginRsp>> CreateOrLoginMemberOnForeign(MemberInfoOnForeign info)
        {
            var result = new RspMsg<MemberLoginRsp>();
            result.statusCode = HttpStatusCode.BadRequest;
            result.Success = false;
            try
            {
                if (string.IsNullOrWhiteSpace(info.ForeignKey))
                {
                    result.Msg = "資料有缺少，請再檢查！";
                    return result;
                }

                Member user = _dBContext.Member.Where(o => o.ForeignKey == info.ForeignKey).FirstOrDefault();

                if (user != null)
                {
                    result.statusCode = HttpStatusCode.OK;
                    result.Msg = "登入成功！";
                }
                if (user == null && string.IsNullOrWhiteSpace(result.Msg))
                {
                    var member = new Member
                    {
                        UserName = info.UserName,
                        Email = info.Email,
                        DeviceId = info.DeviceId,
                        BirthDay = info.BirthDay?.ToString("yyyy-MM-dd") ?? "1970-01-01",
                        Gender = info.Gender,
                        Country = info.Country ?? "",
                        ForeignKey = info.ForeignKey,
                        ImgUrl = info.ImgUrl,
                        Google = info.Google,
                        Apple = info.Apple,
                        Path = ""
                    };

                    await _dBContext.AddAsync(member);
                    await _dBContext.SaveChangesAsync();
                    member.Path = member.UserId + "/" + (!string.IsNullOrWhiteSpace(member.UserName) ? member.UserName : member.ForeignKey) + "/";
                    await _dBContext.SaveChangesAsync();

                    result.statusCode = HttpStatusCode.Created;
                    user = member;
                }

                result.Success = true;
                //組回傳值
                var obj = new MemberLoginRsp
                {
                    UserId = user.UserId,
                    UserName = user.UserName,
                    ForeignKey = user.ForeignKey,
                    Email = user.Email,
                    DeviceId = user.DeviceId,
                    Path = user.Path,
                    PhysicalPath = "https://hannswear.s3-ap-northeast-1.amazonaws.com/" + user.Path,
                    ImgUrl = user.ImgUrl,
                    Birthday = user.BirthDay
                };

                result.obj = obj;
            }
            catch (Exception ex)
            {
                result.Msg = "建立失敗，請稍候再試！";
            }
            return result;
        }

        /// <summary>
        /// 建立會員
        /// </summary>
        public async Task<RspMsg<MemberLoginRsp>> CreateMemberOnInner(MemberInfoOnInner info)
        {
            var result = new RspMsg<MemberLoginRsp>();
            result.Success = false;
            try
            {
                if (string.IsNullOrWhiteSpace(info.Account))
                {
                    result.statusCode = HttpStatusCode.BadRequest;
                    result.Msg = "資料有缺少，請再檢查！";
                }

                Member user = _dBContext.Member.Where(o => o.Account == info.Account).FirstOrDefault(); ;

                if (user != null)
                {
                    result.statusCode = HttpStatusCode.Forbidden;
                    result.Msg = "帳號已存在！";
                }
                if (string.IsNullOrWhiteSpace(result.Msg))
                {
                    var member = new Member
                    {
                        Account = info.Account,
                        Password = info.Password,
                        Email = info.Account,
                        UserName = info.UserName,
                        DeviceId = info.DeviceId,
                        BirthDay = info.BirthDay?.ToString("yyyy-MM-dd") ?? "1970-01-01",
                        Gender = info.Gender,
                        Country = info.Country.ToUpper() ?? "",
                        ImgUrl = info.ImgUrl,
                        Google = false,
                        Apple = false,
                        Path = ""
                    };

                    await _dBContext.AddAsync(member);
                    await _dBContext.SaveChangesAsync();
                    member.Path = member.UserId + "/" + (!string.IsNullOrWhiteSpace(member.UserName) ? member.UserName : member.Account) + "/";
                    await _dBContext.SaveChangesAsync();
                    result.Success = true;

                    //組回傳值
                    var obj = new MemberLoginRsp
                    {
                        UserId = member.UserId,
                        UserName = member.UserName,
                        Account = member.Account,
                        Email = member.Email,
                        DeviceId = member.DeviceId,
                        Path = member.Path,
                        PhysicalPath = "https://hannswear.s3-ap-northeast-1.amazonaws.com/" + member.Path,
                        ImgUrl = member.ImgUrl,
                        Birthday = member.BirthDay
                    };
                    result.statusCode = HttpStatusCode.OK;
                    result.obj = obj;
                }

            }
            catch (Exception ex)
            {
                result.statusCode = HttpStatusCode.InternalServerError;
                result.Msg = "建立失敗，請稍候再試！";
            }
            return result;
        }

        /// <summary>
        /// 更新會員資料
        /// </summary>
        public async Task<Member> UpdateMemberInfo(MemberInfoUpdate info)
        {
            try
            {
                var user = _dBContext.Member.Where(o => o.UserId == info.UserId).FirstOrDefault();
                if (user != null)
                {
                    if (!string.IsNullOrWhiteSpace(info.Password))
                    {
                        user.Password = info.Password;
                    }
                    if (!string.IsNullOrWhiteSpace(info.UserName))
                    {
                        user.UserName = info.UserName;
                    }
                    if (!string.IsNullOrWhiteSpace(info.Email))
                    {
                        user.Email = info.Email;
                    }
                    if (!string.IsNullOrWhiteSpace(info.DeviceId))
                    {
                        user.DeviceId = info.DeviceId;
                    }
                    if (!string.IsNullOrWhiteSpace(info.ImgUrl))
                    {
                        user.ImgUrl = info.ImgUrl;
                    }
                    if (info.BirthDay != null)
                    {
                        user.BirthDay = info.BirthDay?.ToString("yyyy-MM-dd");
                    }

                    await _dBContext.SaveChangesAsync();
                    return user;
                }
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        /// <summary>
        /// 取得使用者資料
        /// </summary>
        public async Task<Member> QueryUser(MemberLogin login)
        {
            try
            {
                Member user = null;
                if (!string.IsNullOrWhiteSpace(login.ForeignKey))
                {
                    user = await _dBContext.Member.Where(o => o.ForeignKey == login.ForeignKey).FirstOrDefaultAsync();
                }
                else
                {
                    user = await _dBContext.Member.Where(o => o.Account == login.Account).FirstOrDefaultAsync();
                }

                return user;
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        public async Task<RspMsg<ForgotPasswordRsp>> ForgotPassword(ForgotPasswordReq req)
        {
            var rsp = new RspMsg<ForgotPasswordRsp>();
            rsp.Success = false;
            try
            {
                if (!string.IsNullOrWhiteSpace(req.Account) && !string.IsNullOrWhiteSpace(req.UserName))
                {
                    var user = await _dBContext.Member.Where(o => o.Account == req.Account && o.UserName == req.UserName
                        && o.BirthDay == req.BirthDay.ToString("yyyy-MM-dd")).FirstOrDefaultAsync();
                    if (user != null)
                    {
                        var msg = $"你的密碼為：{ user.Password } \n若您未申請忘記密碼服務，請迅速前往修改新密碼！";
                        List<string> toMail = new List<string>();
                        toMail.Add(user.Email);
                        var result = await _service.SendMail("Hannswear 忘記密碼！", msg, toMail);
                        var obj = new ForgotPasswordRsp { Account = user.Account, UserName = user.UserName, Password = user.Password };
                        rsp.Success = result;
                        return rsp;
                    }
                }
                rsp.Msg = "查無此帳號！";
            }
            catch (Exception)
            {
                rsp.Msg = "發生錯誤，請稍候再試！";
            }
            return rsp;
        }

        public async Task<string> UrlMapping(string oringin)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(oringin))
                {
                    var data = _dBContext.UrlMapping.Where(o => o.Origin == oringin).FirstOrDefault();
                    if (data != null)
                    {
                        return data.Dest ?? "";
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            return "";
        }

        public async Task<bool> UpdateUrlMapping(string orgin, string dest)
        {
            if(!string.IsNullOrWhiteSpace(orgin) && !string.IsNullOrWhiteSpace(dest))
            {
                var data = await _dBContext.UrlMapping.Where(o => o.Origin == orgin).FirstOrDefaultAsync();
                if (data != null)
                {
                    data.Dest = dest;
                }
                else
                {
                    await _dBContext.UrlMapping.AddAsync(new UrlMapping { Origin = orgin, Dest = dest });
                }

                await _dBContext.SaveChangesAsync();

                return true;
            }
            return false;
        }
    }
}
