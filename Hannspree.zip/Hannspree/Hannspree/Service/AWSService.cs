﻿using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.SimpleEmail;
using Amazon.SimpleEmail.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using System.Web;

namespace Hannspree.Service
{
    public class AWSService
    {
        public BasicAWSCredentials credentials;

        public AWSService()
        {
            credentials = new BasicAWSCredentials("AKIARL66OOTSVTV76J6Q", "rAC5PmFwQYEI/RLIcF9UA2GaPA4lxhfDCeBRiDmD");
        }

        /// <summary>
        /// 上傳檔案到S3
        /// </summary>
        public async Task<string> UploadFileToS3(MemoryStream ms, string key, string bucketName = "hannswear")
        {
            try
            {
                var keyArr = key.Split("/").Select(o => HttpUtility.UrlEncode(o));
                key = string.Join("/", keyArr);
                var client = new AmazonS3Client(credentials, RegionEndpoint.APNortheast1);
                PutObjectResponse response = await client.PutObjectAsync(new PutObjectRequest
                {
                    BucketName = bucketName,
                    Key = key,
                    InputStream = ms,
                    CannedACL = S3CannedACL.PublicRead
                });

                if (response.HttpStatusCode == HttpStatusCode.OK)
                {
                    return "https://hannswear.s3-ap-northeast-1.amazonaws.com/" + key;
                }
            }
            catch (Exception ex)
            {
                string s = ex.Message;
            }
            return "";
        }

        public async Task<bool> DeleteFileOnS3(string key, string bucketName = "hannswear")
        {
            var client = new AmazonS3Client(credentials, RegionEndpoint.APNortheast1);
            DeleteObjectResponse response = await client.DeleteObjectAsync(bucketName, key);

            if (response.HttpStatusCode == HttpStatusCode.OK)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 從S3取得單一檔案
        /// </summary>
        public async Task<GetObjectResponse> GetObject(string key, string bucketName = "hannswear")
        {
            try
            {
                var client = new AmazonS3Client(credentials, RegionEndpoint.APNortheast1);
                GetObjectResponse response = await client.GetObjectAsync(bucketName, key);
                return response;
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        public async Task<long> CalculateFolderSize(string folderName, string bucketName = "hannswear")
        {
            long totalSize = 0;
            try
            {
                var client = new AmazonS3Client(credentials, RegionEndpoint.APNortheast1);

                var request = new ListObjectsV2Request
                {
                    BucketName = bucketName,
                    Prefix = folderName
                };
                ListObjectsV2Response response;
                do
                {
                    response = await client.ListObjectsV2Async(request);
                    foreach (S3Object o in response.S3Objects)
                    {
                        totalSize += o.Size;
                    }
                    request.ContinuationToken = response.ContinuationToken;
                } while (response.IsTruncated);

            }
            catch (Exception)
            {

                throw;
            }
            return totalSize;
        }

        public async Task<bool> SendMail(string subject, string content, List<string> toAddresses)
        {
            var client = new AmazonSimpleEmailServiceClient(credentials, RegionEndpoint.APNortheast1);
            SendEmailResponse response = await client.SendEmailAsync(new SendEmailRequest
            {
                Source = "Customer@hannswear.com",
                Destination = new Destination { ToAddresses = toAddresses, BccAddresses = toAddresses, CcAddresses = toAddresses },
                Message = new Message
                {
                    Subject = new Content { Charset = "UTF-8", Data = subject },
                    Body = new Body { Text = new Content { Charset = "UTF-8", Data = content } }
                }
            });
            if (response.HttpStatusCode == HttpStatusCode.OK)
            {
                return true;
            }
            return false;
        }
    }
}
