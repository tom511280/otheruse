﻿using IdentityServer4.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hannspree
{
    public class IdentityConfig
    {
        // 定義有哪些API資源，相當於 SampleCode 的 WebApi
        public static IEnumerable<ApiResource> GetResources()
        {
            return new[]
            {
            new ApiResource("api1", "MY API")
        };
        }

        // 定義使用者，相當於 SampleCode 的 Client
        public static IEnumerable<Client> GetClients()
        {
            return new List<Client>
        {
            new Client
            {
                ClientId = "client",
                AllowedGrantTypes = GrantTypes.ClientCredentials,
                ClientSecrets =
                {
                    new Secret("secret".Sha256()),
                },
                // 這個 client 允許使用的 scope
                AllowedScopes = { "api1" }
            }
        };
        }

        public static IEnumerable<ApiScope> GetScopes()
        {
            return new List<ApiScope>()
        {
            new ApiScope()
            {
                Name = "api1"
            }
        };
        }
    }
}
