﻿using System;

namespace Libery
{
    public class Class1
    {
    }
}
